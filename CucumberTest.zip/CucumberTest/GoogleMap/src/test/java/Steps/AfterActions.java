package Steps;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import utils.SeleniumDriver;

public class AfterActions {

	@After
	public static void tearDown(Scenario scenario) {
		
		WebDriver driver= SeleniumDriver.getDriver();
		System.out.println(scenario.isFailed());
		if(scenario.isFailed()) {
			File scr = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			
			try {
				FileUtils.copyFile(scr, new File("screenshot.png"));
				} catch(IOException e) {
					e.printStackTrace();
				}
		}
		
		SeleniumDriver.tearDown();
	}
	
}
