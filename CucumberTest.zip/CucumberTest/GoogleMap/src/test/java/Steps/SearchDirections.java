package Steps;

import java.io.File;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.actions.GoogleMapHomePageActions;
import pages.actions.SearchResultPageActions;
import pages.locators.SearchResultPageLocators;
import utils.SeleniumDriver;

public class SearchDirections {
	GoogleMapHomePageActions googleMapHomePageActions = new GoogleMapHomePageActions();
	SearchResultPageActions searchResultPageActions = new SearchResultPageActions();
	
@Given("^I am on the Home Page \"([^\"]*)\"$")
public void i_am_on_the_Home_Page(String webSiteURL) {
	SeleniumDriver.openPage(webSiteURL);
}

@When("^User searches \"([^\"]*)\"$")
public void user_searches(String cityName) {
			SeleniumDriver.waitForPageToLoad();
		googleMapHomePageActions.inputCityName(cityName);
		
	}

@When("^User verifies cordinates for San Francisco is \"([^\"]*)\"$")
public void user_verifies_cordinates_for_San_Francisco_is(String coordinates) {
	SeleniumDriver.waitForPageToLoad();
	String currentURL = SeleniumDriver.getCurrentUrl();
	if(currentURL.contains(coordinates))
	{
		System.out.println("URL contins correct coordinates");
	}
	else
	{
		try {
			throw new Exception("URL doesnot contains correct coordinates");
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
	
}

@When("^Userclicks on Directions$")
public void userclicks_on_Directions() {
	searchResultPageActions.clickOnDirectionsButton();
}

@When("^User enters starting and destination cities$")
public void user_enters_starting_and_destination_cities(DataTable table) {
List<List<String>> data = table.raw();
searchResultPageActions.inputStartingPoint(data.get(1).get(0));
searchResultPageActions.inputDestination(data.get(1).get(1));
searchResultPageActions.clickOnDrivingButton();
}

@Then("^Available routes will be displayed to user$")
public void available_routes_will_be_displayed_to_user() {
	try
	{
		SeleniumDriver.waitForPageToLoad();
		if(new File("routes.txt").exists())
		{
			SeleniumDriver.FlushTextFile("routes.txt");
		}
		List<WebElement> routeTitleList = SeleniumDriver.getDriver().findElements(By.xpath("//h1[contains(@id,'section-directions-trip-title')]/span"));
		List<WebElement> distanceList = SeleniumDriver.getDriver().findElements(By.xpath("//div[contains(@class,'section-directions-trip-duration delay-light')]/span[1]"));
		List<WebElement> durationList = SeleniumDriver.getDriver().findElements(By.xpath("//div[contains(@class,'section-directions-trip-distance section-directions-trip-secondary-text')]/div"));
		for (int i =0; i<routeTitleList.size();i++)
		{
			SeleniumDriver.writeTextFile("routes.txt", "Route Title: "+ routeTitleList.get(i).getText());
			SeleniumDriver.writeTextFile("routes.txt", " Distance In Miles: "+distanceList.get(i).getText());
			SeleniumDriver.writeTextFile("routes.txt", " Travel Time: "+durationList.get(i).getText());
		}
	}catch (Exception e)
	{
	e.printStackTrace();		
	}
}

}
