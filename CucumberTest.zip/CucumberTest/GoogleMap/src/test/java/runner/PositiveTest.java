package runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(
		features = "src/test/resources/FeatureFiles",
		glue = "Steps",
		tags = {"@Search-Directions"}
		//,dryRun=true
		)

public class PositiveTest extends AbstractTestNGCucumberTests {

	}
