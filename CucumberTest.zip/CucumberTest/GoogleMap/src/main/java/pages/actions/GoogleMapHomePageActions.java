package pages.actions;

import org.openqa.selenium.Keys;
import org.openqa.selenium.support.PageFactory;

import pages.locators.GoogleMapHomePageLocators;
import utils.SeleniumDriver;

public class GoogleMapHomePageActions {

	 GoogleMapHomePageLocators googleMapHomePageLocators=null;
	public GoogleMapHomePageActions()
	{
		this.googleMapHomePageLocators = new GoogleMapHomePageLocators();
		PageFactory.initElements(SeleniumDriver.getDriver(), googleMapHomePageLocators);
	}
	
	public void inputCityName(String cityName) 
	{
		
		googleMapHomePageLocators.searchbox.sendKeys(cityName);
		googleMapHomePageLocators.searchbox.sendKeys(Keys.ENTER);
	}
}
