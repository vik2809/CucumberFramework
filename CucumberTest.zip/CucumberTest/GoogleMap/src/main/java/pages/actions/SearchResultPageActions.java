package pages.actions;

import org.openqa.selenium.support.PageFactory;

import pages.locators.SearchResultPageLocators;
import utils.SeleniumDriver;

public class SearchResultPageActions {

	SearchResultPageLocators searchResultPageLocators = null;
	
	public SearchResultPageActions() {
		
		this.searchResultPageLocators = new SearchResultPageLocators();
		PageFactory.initElements(SeleniumDriver.getDriver(), searchResultPageLocators);
	}
	
	public void cityNameIsDisplayed(String cityName) {
		searchResultPageLocators.searchedCityName.getText().equalsIgnoreCase(cityName);
	}
	public void clickOnDirectionsButton() {
		searchResultPageLocators.directionButton.click();
		
	}
	public void inputStartingPoint(String startingPoint)
	{
		searchResultPageLocators.startingPointInputBox.sendKeys(startingPoint);
	}
	
	public void inputDestination(String destination)
	{
		searchResultPageLocators.destinationInputBox.sendKeys(destination);
	}
	
	public void clickOnDrivingButton()
	{
		searchResultPageLocators.drivingButton.click();
	}

}
