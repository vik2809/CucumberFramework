package pages.locators;

import javax.lang.model.element.Element;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class SearchResultPageLocators {

	@FindBy(how=How.XPATH,using="//h1/span[1]")
	public WebElement searchedCityName;
	
	@FindBy(how=How.XPATH,using="//button[@data-value=\"Directions\"]")
	public WebElement directionButton;
	
	@FindBy(how=How.XPATH,using="//input[contains(@aria-label,'tarting point')]")
	public WebElement startingPointInputBox;
	
	@FindBy(how=How.XPATH,using="//input[contains(@aria-label,'Destination')]")
	public WebElement destinationInputBox;
	
	@FindBy(how=How.XPATH,using="//button/img[@aria-label='Driving']")
	public WebElement drivingButton;


}
