package utils;

import java.util.NoSuchElementException;

import org.openqa.selenium.WebElement;

public class SeleniumHelper {

	public static boolean isElemenPresent(WebElement webElement) {
		
		try {
			boolean isPresent = webElement.isDisplayed();
			return isPresent;
		} catch(NoSuchElementException e) {
			return false;
		}
	}
	
}
