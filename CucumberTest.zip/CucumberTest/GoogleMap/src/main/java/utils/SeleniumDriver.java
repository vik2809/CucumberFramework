package utils;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SeleniumDriver {

	private static SeleniumDriver seleniumDriver;
	private static WebDriver driver;
	
	private static WebDriverWait waitDriver;
	public final static int Timeout = 30;
	public final static int Page_Load_Timeout = 50;
	
	private SeleniumDriver() {
		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		waitDriver = new WebDriverWait(driver, Timeout);
		driver.manage().timeouts().implicitlyWait(Timeout, TimeUnit.SECONDS);
		String window = driver.getWindowHandle();
		System.out.println("window ->"+ window);
	}
	
	public static void openPage(String url) {
		
		System.out.println(url);
		System.out.println(driver);
		driver.get(url);
	}
	
	public static String getCurrentUrl() {
		return (driver.getCurrentUrl());
	}
	
	public static WebDriver getDriver() {
		return driver;
	}
	
		
	public static void setupDriver() {
		if(seleniumDriver == null)
			seleniumDriver = new SeleniumDriver();
	}
	
	public static void tearDown() {
		if(driver != null) {
			driver.close();
			driver.quit(); }
		seleniumDriver = null;
	}
	
	public static void writeTextFile(String fileName,String textToWrite) throws IOException
	{
		FileWriter writer = new FileWriter(fileName, true);
		BufferedWriter bufferedWriter = new BufferedWriter(writer);
		bufferedWriter.write(textToWrite);
		bufferedWriter.newLine();
		bufferedWriter.close();
	}
	
	public static void waitForPageToLoad() {
		try {
			Thread.sleep(8000);
		} catch(InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void FlushTextFile(String fileName)
	{
		PrintWriter pw;
		try {
			pw = new PrintWriter(fileName);
			pw.write("");
			pw.flush();
			pw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}

